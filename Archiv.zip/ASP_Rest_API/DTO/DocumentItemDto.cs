﻿namespace ASP_Rest_API.DTO
{
    public class DocumentItemDto
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
