﻿namespace DAL.Entities
{
    public class DocumentItem
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
